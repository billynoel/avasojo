package com.api.services;

public class FacebookBidManagerAvasojoWrapper {

}
